module TarsCli.RunAutoGen
// Entry point: parse .tars, write agentic_module_autogen.json, run Python