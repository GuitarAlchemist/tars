module DiffValidator
// Compares two .tars versions and validates evolution logic