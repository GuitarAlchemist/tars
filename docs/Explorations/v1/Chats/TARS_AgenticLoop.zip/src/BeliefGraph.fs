module BeliefGraph
// Writes belief_graph { ... } block into next .tars