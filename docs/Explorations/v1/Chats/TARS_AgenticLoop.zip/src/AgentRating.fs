module AgentRating
// Writes agent_rating { ... } block into next .tars