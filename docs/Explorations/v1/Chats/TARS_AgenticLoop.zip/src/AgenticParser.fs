module AgenticParser
// Parses multiple agentic blocks from .tars files