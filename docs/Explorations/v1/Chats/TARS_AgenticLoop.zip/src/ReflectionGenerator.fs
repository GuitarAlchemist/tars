module ReflectionGenerator
// Injects trace + meta-feedback into next agentic .tars