# TARS Agentic Loop

This prototype includes:

- Multi-agent parsing
- AutoGen integration
- Reflection and meta-feedback
- Belief graph + agent ratings
- Automatic rollback handling
