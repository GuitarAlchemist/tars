import json
from autogen import AssistantAgent, UserProxyAgent, GroupChat, GroupChatManager

with open("agentic_module_autogen.json") as f:
    config = json.load(f)

agents = []
for agent in config["agents"]:
    a = AssistantAgent(
        name=agent["name"],
        system_message=agent["goal"],
        tools=agent.get("tools", [])
    )
    agents.append(a)

user_proxy = UserProxyAgent(
    name="User",
    human_input_mode="NEVER",
    default_auto_reply="Okay, working on it..."
)

messages = config["agents"][0].get("messages", [])

chat = GroupChat(
    agents=[user_proxy] + agents,
    messages=messages,
    max_round=5
)

manager = GroupChatManager(groupchat=chat, llm_config={"model": "llama3"})
manager.run()