# Docs Index (TARS v2)

- **Architecture**
  - `Architecture/Metascript_Specification.md`: DSL structure and semantics.
- **Roadmap**
  - `3_Roadmap/implementation_plan.md`: overall delivery plan.
  - `3_Roadmap/phase_6_7_summary.md`: latest phase summary + status.
  - `3_Roadmap/phase_6_7_epistemic_governor.md`: governor integration notes.
  - `3_Roadmap/phase6_integration_strategy.md`: integration sequencing.
- **QA / Ops**
  - `QA/Testing_Tips.md`: test commands, lock cleanup, offline eval.
  - `QA/Competence_Metrics.md`: runtime metrics + offline eval harness.
  - `QA/Grammar_Distillation.md`: grammar spec scaffolding and usage hints.
- **Tutorials / Examples**
  - `1_Tutorials/` (if present) and `demos/` scripts (CLI/chat/demo runs).
- **Research / Analysis**
  - `2_Analysis/` research summaries and synthesis.
  - `__research/state_space_observability_for_agent_mesh.md`: state-space lens for observability/controllability/stability of the agent mesh.

Quick jump:
- Tests: see `QA/Testing_Tips.md`.
- Metrics/eval: see `QA/Competence_Metrics.md`.
- Grammar scaffold: see `QA/Grammar_Distillation.md`.
