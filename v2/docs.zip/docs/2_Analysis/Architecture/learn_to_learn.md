# Teaching TARS How to Learn to Learn

**Last Updated:** November 29, 2025
**Status:** Living Document
**Related:** [Epistemic Governor](epistemic_governor.md) | [Graphiti Research](../Research/graphiti_integration_research.md) | [Grammar Integration](grammar-knowledge-integration.md)

---

## 1. Purpose

This document explains how to operationalize *meta-learning* in TARS v2 so the system improves its own reasoning, tooling, and prompts over time. It ties together existing components (Curriculum/Executor/Evaluator, Epistemic Governor, Grammar Distillation, Metascripts, Trace Recorder, Toolsmithing) into a governed loop with measurable progress.

---

## 2. Definition

**"Learn to learn"** = TARS runs a closed loop that:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        META-LEARNING CYCLE                              │
│                                                                         │
│    OBSERVE ──▶ ABSTRACT ──▶ EDIT ──▶ VALIDATE ──▶ DEPLOY               │
│        │                                              │                 │
│        └──────────────────────────────────────────────┘                 │
│                         (feedback loop)                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

The goal is to increase **transfer** (generalization to new tasks) while keeping **safety constraints** (budgets, K-theory invariants, epistemic gates) intact.

### 2.1 Key Principles

| Principle | Description | Mechanism |
|-----------|-------------|-----------|
| **Temporal Awareness** | Track when beliefs become valid/invalid | Graphiti-style bi-temporal model |
| **Contradiction Handling** | Detect and resolve conflicting beliefs | Temporal edge invalidation |
| **Pattern Clustering** | Group similar learnings for abstraction | Community detection algorithms |
| **Grammar Evolution** | Distill patterns into reusable F# code | Grammar distillation pipeline |
| **Safe Deployment** | Validate changes before promotion | A/B testing + auto-revert |

---

## 3. Prerequisites (Minimum Viable Stack)

| Component | Purpose | Implementation |
|-----------|---------|----------------|
| **Tracing** | Reproduce runs deterministically | Trace Recorder + Mock Tool framework ([BRIDGING_THE_GAPS](03_Operational/BRIDGING_THE_GAPS.md)) |
| **Knowledge** | Store extracted principles | BeliefGraph (Graphiti-style) + VectorStore |
| **Constraints** | Enforce output formats | GrammarDistillation (GBNF) + style rules |
| **Policy Knobs** | Control execution | BudgetGovernor, Safety gates, Circuit Breakers |
| **Execution** | Run learning tasks | Metascript engine + Tars.Graph + Sandbox |
| **Temporal Store** | Track belief evolution | Bi-temporal episode/entity/community graph |

---

## 4. The Meta-Learning Loop (Ouroboros)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            OUROBOROS LOOP                                   │
│                                                                             │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐              │
│  │ 1.PROPOSE│───▶│ 2.EXECUTE│───▶│3.EVALUATE│───▶│ 4.DISTILL│              │
│  │Curriculum│    │ Executor │    │ Governor │    │ Grammar  │              │
│  └──────────┘    └──────────┘    └──────────┘    └────┬─────┘              │
│       ▲                                               │                    │
│       │         ┌──────────┐    ┌──────────┐    ┌─────▼────┐              │
│       └─────────│7.MONITOR │◀───│ 6.POLICY │◀───│5.TOOLSMITH│              │
│                 │  Deploy  │    │  Update  │    │ Synthesize│              │
│                 └──────────┘    └──────────┘    └──────────┘              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Step 1: Propose (Curriculum Agent)

The Curriculum Agent samples tasks using a **multi-armed bandit** strategy:

```fsharp
type TaskBucket =
    | Regression of knownGap: string      // Retry past failures
    | Exploration of domain: string       // Try new areas
    | Drill of strength: string           // Reinforce known skills
    | Contradiction of beliefA: Guid * beliefB: Guid  // Resolve conflicts

type CurriculumSample = {
    Task: TaskDefinition
    Bucket: TaskBucket
    Budget: TokenBudget
    AllowedTools: ToolId list
    KnowledgeBoundary: string list  // Which beliefs can be used
}
```

**Sampling Policy**: UCB (Upper Confidence Bound) or Thompson Sampling over buckets, with reward = `f(success, cost_delta, novelty)`.

### 4.2 Step 2: Execute (Executor Agent)

```fsharp
type ExecutionTrace = {
    TaskId: Guid
    Messages: Message list          // Full dialogue
    ToolCalls: ToolCall list        // Tools invoked
    BudgetDeltas: BudgetDelta list  // Token/time/cost changes
    Errors: Error list              // Failures encountered
    Outcome: ExecutionOutcome       // Success/Failure/Partial
    Timestamp: DateTime             // For temporal tracking
}
```

**Key**: Emit **dense traces** as Episodes for the Graphiti-style knowledge graph.

### 4.3 Step 3: Evaluate (Epistemic Governor)

The [Epistemic Governor](epistemic_governor.md) performs:

1. **Falsification**: Generate variants, test generalization
2. **Extraction**: Distill solution into abstract `Belief`
3. **Contradiction Detection**: Compare with existing beliefs

```fsharp
type EvaluationResult = {
    TaskId: Guid
    GeneralizationScore: float      // 0.0-1.0: how well it transfers
    ExtractedBeliefs: Belief list   // New principles learned
    Contradictions: Contradiction list  // Conflicts with existing beliefs
    BrittlePaths: string list       // Flagged as non-generalizable
}

type Contradiction = {
    ExistingBelief: Belief
    NewBelief: Belief
    Resolution: ContradictionResolution
}

type ContradictionResolution =
    | InvalidateOld of reason: string   // New belief supersedes
    | RejectNew of reason: string       // Existing belief wins
    | Merge of mergedBelief: Belief     // Combine both
    | Scope of oldScope: string * newScope: string  // Both valid in different contexts
```

### 4.4 Step 4: Distill & Constrain (Grammar Evolution Agent)

Convert patterns into grammars using community detection:

```fsharp
type GrammarDistillationInput = {
    SuccessfulTraces: ExecutionTrace list
    ExtractedBeliefs: Belief list
    PatternClusters: Community list  // From Graphiti-style clustering
}

type DistilledArtifact =
    | GBNFRule of name: string * production: string
    | StyleRule of name: string * constraint: string
    | MetascriptTemplate of name: string * dag: MetascriptNode list
    | FSharpType of name: string * definition: string  // New DU or CE
```

### 4.5 Step 5: Toolsmithing (Tool Synthesis Agent)

Detect patterns that warrant new tools:

```fsharp
type ToolCandidate = {
    Name: string
    TriggerConditions: TriggerCondition list
    ProposedSchema: ToolSchema
    EstimatedSavings: CostEstimate
    TestCases: TestCase list
}

type TriggerCondition =
    | RepetitionAboveThreshold of count: int
    | LatencyAboveBaseline of ratio: float
    | BudgetBurnAboveBaseline of ratio: float
    | FlakeRateAboveThreshold of rate: float
```

**Rule**: Require **two signals** before proposing a tool (e.g., repetition + latency).

### 4.6 Step 6: Policy Update (Governance)

```fsharp
type PolicyUpdate = {
    RoutingChanges: RoutingRule list      // Model selection heuristics
    RetrievalKnobs: RetrievalConfig       // Fan-out limits, top-k
    CurriculumWeights: Map<TaskBucket, float>  // Updated sampling
    CircuitBreakerUpdates: BreakerUpdate list
}
```

### 4.7 Step 7: Redeploy & Monitor

```fsharp
type DeploymentStrategy =
    | Shadow of baseline: Version * candidate: Version
    | ABTest of allocation: float  // % traffic to candidate
    | Canary of rolloutPct: float * duration: TimeSpan

type PromotionCriteria = {
    MinStabilityRuns: int
    MaxFlakeRateIncrease: float
    MaxCostIncrease: float
    MinSuccessRateDelta: float
}
```

**Auto-revert**: If metrics regress beyond thresholds, automatically roll back.

---

## 5. Data Products (Graphiti-Style Three-Tier Model)

Following the [Graphiti research](../Research/graphiti_integration_research.md), organize data into three tiers:

### 5.1 Episode Layer (Gₑ) - Raw Data
| Product | Format | Purpose |
|---------|--------|---------|
| **Traces** | JSON Lines | Full dialogue + tool calls + budgets + outcomes (source of truth) |
| **Code Changes** | Git diffs | What was modified |
| **Tool Invocations** | Structured logs | Who called what, when |

### 5.2 Semantic Entity Layer (Gₛ) - Extracted Knowledge
| Product | Format | Purpose |
|---------|--------|---------|
| **Beliefs** | Vector-embedded | Abstract principles with confidence, lineage, temporal validity |
| **Grammars** | GBNF + F# | Constrained output formats |
| **Tools** | Registry entries | Metadata: schema, health, cost, win rate |

### 5.3 Community Layer (Gₖ) - Clustered Patterns
| Product | Format | Purpose |
|---------|--------|---------|
| **Pattern Families** | Cluster IDs | Groups of related beliefs/grammars |
| **Module Communities** | Graph clusters | Strongly connected code areas |
| **Skill Trees** | DAG | Prerequisite relationships between capabilities |

## Metrics to Track
- **Task Success:** Pass rate, time-to-first-solution, retry count.
- **Generalization:** Pass rate on Governor-generated variants; transfer to new repos.
- **Stability:** Flake rate across seeds/runs; divergence between trace replay and live.
- **Cost & Budget:** Tokens, wall-clock, money per solved task; budget violations.
- **Tool Health:** Error rate per tool; breaker trips; mean time to recovery.
- **Drift:** Grammar/style violations per 100 generations; entropy of context vs. BeliefGraph anchor set.

## Implementation Phases
**Phase 0 (Now): Manual loop**
- Record traces; hand-run Governor prompts to extract beliefs; hand-edit grammar/style rules; manually craft new tools when repetition is obvious.

**Phase 1: Deterministic replay + mock tools**
- Build Trace Recorder + Mock Tool framework; ensure any run can be replayed without live tools.
- Add Trace Diff tool to compare golden vs. new traces.

**Phase 2: Automated extraction**
- Automate EpistemicGovernor prompts after each successful run to produce Beliefs.
- Feed Beliefs into GrammarDistillation to emit GBNF/style fragments; append to constraints.

**Phase 3: Curriculum-driven self-play**
- Nightly Curriculum batch: N tasks sampled; executor runs; Governor evaluates; Grammar/Belief store updates.
- Store per-task metrics; surface dashboards (CLI summary acceptable initially).

**Phase 4: Toolsmithing + registry health**
- Add Tool Synthesis Agent that inspects traces for repeated, costly spans; proposes a tool spec + tests.
- Introduce ToolHealthMonitor (breaker) and require health metadata before promotion.

**Phase 5: Safe promotion**
- Shadow new grammars/tools via A/B; promote on green metrics; auto-revert on regressions.
- Maintain signed changelog of self-modifications (who/when/why) for audit.

## Safety & Governance Hooks
- **BudgetGovernor:** Enforce per-task token/time/money caps; degrade to summarize/exit.
- **Loop/Entropy Watchdogs:** Abort or cool when no state change occurs or context entropy rises.
- **Circuit Breakers:** Quarantine failing tools; reroute to fallbacks.
- **Knowledge Boundaries:** Tag tasks with allowed sources; refuse to cross boundaries.
- **Human Checkpoints:** Allow manual approval for tool promotion and grammar tightening in early phases.

## How to Teach (Operational Playbook)
- Start with a small, curated task list (unit tests, doc fixes) and daily self-play window.
- After each run, automatically: replay trace → run Governor → update BeliefGraph → regenerate constraints → store metrics → prepare A/B cohort for next day.
- Weekly: review new beliefs/tools/grammars; prune low-confidence items; refresh Curriculum weights.
- Monthly: export audit of self-changes and their measured impact.

## Open Questions (and stronger defaults)
- **Curriculum sampling:** Default to a multi-armed bandit over task buckets (regression, exploration, drills) with reward = composite of success, cost delta, and novelty. Heuristic buckets alone are brittle; use UCB/Thompson to adapt.
- **Tool creation triggers:** Require two signals before proposing a tool: (1) repetition count above threshold *and* (2) excess latency or budget burn vs. baseline; optionally include high flake rate as a tiebreaker.
- **Grammar tightening:** Gate automatic tightening behind stability checks: no increase in flake rate over N runs and no rise in grammar violation count. Roll out via shadow + A/B; auto-revert on regressions.
