namespace TARS.Core

module AgentLogic =
    let executeAgent name =
        printfn $"[AgentLogic] Simulating agent {name} task execution..."