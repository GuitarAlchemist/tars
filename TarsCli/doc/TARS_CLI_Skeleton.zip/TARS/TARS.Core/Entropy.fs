namespace TARS.Core

module Entropy =
    let calculateEntropy (graphSize: int) (loopCount: int) =
        float loopCount / float (graphSize + 1)