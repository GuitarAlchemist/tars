namespace TARS.Core

type TaskStatus = Pending | InProgress | Completed | Failed

type AgentInteraction =
    { Source: string
      Target: string
      Type: string
      Outcome: string }

type Task =
    { Id: string
      Description: string
      Status: TaskStatus
      AssignedAgent: string
      Result: string option }

type TarsFile =
    { Version: string
      Timestamp: string
      Summary: string
      Tasks: Task list
      AgentInteractions: AgentInteraction list }