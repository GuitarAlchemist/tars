using System.IO;
using System.Text.Json;

namespace TARS.Cli
{
    public static class MetaGenerator
    {
        public static void Generate(string outputPath)
        {
            Console.WriteLine("[MetaGenerator] Generating .tars file...");
            var meta = new {
                version = "v0.4",
                summary = "Initial entropy scoring + diagnostic run",
                timestamp = DateTime.UtcNow.ToString("o")
            };
            var json = JsonSerializer.Serialize(meta, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(Path.Combine(outputPath, "v0.4.tars"), json);
        }
    }
}