using System;
using TARS.Cli;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Usage: tarscli run [-diagnostics] [-meta] [-review] [-plan-next]");
            return;
        }

        var cmd = args[0].ToLower();
        switch (cmd)
        {
            case "run":
                if (args.Contains("-diagnostics"))
                    DiagnosticsRunner.Run();
                if (args.Contains("-meta"))
                    MetaGenerator.Generate("output/versions/v0.4");
                break;
            case "-review":
                AgentExecutor.Execute("Critic");
                break;
            case "-plan-next":
                AgentExecutor.Execute("Director");
                break;
            default:
                Console.WriteLine("Unknown command.");
                break;
        }
    }
}