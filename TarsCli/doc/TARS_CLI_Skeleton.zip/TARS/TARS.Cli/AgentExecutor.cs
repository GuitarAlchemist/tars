namespace TARS.Cli
{
    public static class AgentExecutor
    {
        public static void Execute(string agentName)
        {
            Console.WriteLine($"[AgentExecutor] Executing agent: {agentName}");
            // Simulate F# agent execution via bindings or file-based protocol
        }
    }
}